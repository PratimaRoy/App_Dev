import React from 'react';
import ReactDOM from 'react-dom/client';
import User from './comments'
import March from './images/Marh7.jpeg'
import Asta from './images/Asta.jpeg'
import Bailu from './images/Bailu.jpeg'
import User__Feedback from './UserFeedBack'
import Himeko from './images/Himeko.jpeg'
import Kafka  from'./images/Kafka.jpeg'
import Serval from './images/Serval.jpeg'
import Yukong from './images/Yukong.jpeg'
import Card from './card'
const App = function(){
  return (
    <div className='ui comments'>
      <User__Feedback>
      <User name = 'Ms. March'
      date = '8:30AM'
      msg = 'Hey I just woke up'
      picture = {March }
      />
      </User__Feedback>
      
      <User__Feedback>
      <User name = 'Ms. Asta'
      date = '9:30AM'
      msg = 'Good Morning!'
      picture = {Asta }
      />
      </User__Feedback>

      <User__Feedback>
      <User name = 'Ms. Bailu'
      date = '4PM'
      msg = 'Good Afternoon'
      picture = {Bailu}
      />
    </User__Feedback>

  
    <Card picture = {Himeko}
     title = 'Himeko is a fire sexy woman she has a bulldozer to fight.' 
     info = 'Her Abilities and Personalities'
     msg = '"Drinks Tea," "Flirting," and "Charming".'   
    >
      
    </Card>
     
     
   <Card picture = {Kafka }
    title = 'She is an electro woman she knows how to shoot and is sexy'
    info = 'Her Abilities and Personalities'
    msg = '"Shooting," "Charming," and "Makes people dizzy"'
   >
    
    </Card>
     
     <Card picture = {Serval }
       title = 'Serval is in a band and she is an electro mommy as well.'
       info = 'Her Abilities and Personalities'
       msg = '"Singer," "Charming," and "Caring sister"'
    >
      </Card>
     
      <Card picture = {Yukong}
          title = 'Yukong has amazing imaginary skills and she runs fast.'
          info = 'Her Abilities and Personalities'
          msg = '"Racer," "Workaholic," and "Loving".'
      >
      </Card> 
    </div>
  )
}

//rooting
const root = ReactDOM.createRoot(document.querySelector("#root"))
root.render(App())

// create a zip folder of Public and src folders 




