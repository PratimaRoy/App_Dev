import React from 'react'
const Home = function(){
    return(
        <div className='ui raised very padded text container' style={{marginTop: "3em"}}>
            <h2 className='ui header'>Home </h2>
            <p>Hi, Welcome to the website!</p>
        </div>
    )
}
export default Home