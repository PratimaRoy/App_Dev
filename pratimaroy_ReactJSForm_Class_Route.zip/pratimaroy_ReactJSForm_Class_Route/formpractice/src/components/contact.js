import React from 'react'
const Contact= function(){
    return(
        <div className='ui raised very padded text container' style={{marginTop: "3em"}}>
            <h2 className='ui header'>Contact </h2>
            <p>Contact me at my gmail: pratimaroy170@gmail.com</p>
        </div>
    )
}
export default Contact