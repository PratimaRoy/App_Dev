import React from 'react'
const About = function(){
    return(
        <div className='ui raised very padded text container' style={{marginTop: "3em"}}>
            <h2 className='ui header'>About Us </h2>
            <p>Hi my name is Pratima Roy and I love coding with people who love it as well! Everyone needs to help each other and learn together!</p>
        </div>
    )
}
export default About