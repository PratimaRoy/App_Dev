import { User } from "./user.model";

export class dataSoure{
    private users:User[]
    constructor(){
        this.users = new Array<User>(
            new User(1, 'Pratima ', "pratimaroy170@gmail.com")
        )
        }

        getUser():User[]{
            return this.users
        }
}
