const helper = function(data) {
    return `${data} is logged in!`
};

const id = function(i) {
    return `ID is ${i}`
}

let email = function(e) {
    return e
}

//one line export object
module.exports = {
    helper, id, email
}
