const user = require('./mod')

console.log(user.helper('Peter'))
console.log(user.id(123))
console.log(user.email('Peter@gmail.com'))


